---
spec: { envelope: 1, experience: 2, grammar: 1 }
doc_version: 1.0.0
status: current
last_verified: 2026-07-14
audience: llm-agent
---

# Authoring procedure

**The algorithm.** Follow these steps in order. Do not skip steps 6-8.

> **Starting from a filled-in product doc?** (identity, personas, workflow types, surfaces, seed data —
> this shape, not only a doc named exactly "Community Product Experience Template.") **One fact from that
> conversion process is important enough to state directly here, not just in a file you might not have in
> this bundle:** a product doc's "Persona Tabs, Pins, And Customization" table (listing which tabs each
> persona is described as using) is **descriptive UX copy, not an access-control mechanism.** Per-persona
> different tab sets are not real grammar in this schema version — every tab a workflow binds to is visible
> to whichever persona a `role`/guard combination actually resolves for, regardless of what that table
> says. Found 2026-08-10 (Skill Retrospective): an authoring pass read a persona's "required tabs" list,
> concluded that persona could never see a card bound to a tab not on that list, and used that false belief
> to justify dropping a real product-doc requirement — while the very same JSON it had just written already
> used `role: "any"` on that exact tab, which the real grammar renders to everyone. Do not make this
> inference; check the actual `tabId`/`role` resolution rules in `12-render-bindings.md` instead.

## Mental model (one paragraph)

A community is a set of **state machines** declared in JSON and executed by a real engine. You declare
*what states a thing can be in*, *what transitions move between them*, *who may fire each* (guards),
*what changes when they fire* (effects), *what is derived rather than stored* (formulas), and *where it
appears* (render bindings). You never author UI and never author code. The app renders the declaration.

---

## Step 1 — Extract personas

From the requirements, list every distinct actor. Each becomes a persona.

```jsonc
"personas": [
  { "personaId": "<kebab-id>", "label": "<short>", "roleLabel": "<short>",
    "description": "<what they do>" }
]
```

**Rule:** every `allowedPersonaIds` entry you write later MUST be a `personaId` declared here. The
validator warns on dangling persona ids.

---

## Step 2 — Enumerate the "things" (→ workflow types)

List every distinct kind of object the community manipulates. Each becomes **one entry** in
`workflowDefinitions`.

**Type vs instance — critical:**
- A community with 40 hikes has **one** `hike-rsvp` *type* and **40** *instances*.
- A community with hikes AND book-swaps has **two** types.

**Test:** *do these two things have the same states and the same transitions?* If yes → one type, two
instances. If no → two types.

---

## Step 3 — For each type, decide states vs data

**This is the highest-risk step. Most modeling bugs originate here.**

Apply this decision rule to every candidate condition:

> **Can this be true at the same time as another condition in the same dimension?**
> - **Yes** → it is **data** (`instanceData` + an orthogonal transition, `"to": null`).
> - **No — it genuinely replaces the previous condition** → it is a **state**.

### Decision table

| Condition | Simultaneous with others? | Verdict |
|---|---|---|
| Event is `open` / `cancelled` | No — mutually exclusive | **state** |
| Member has RSVP'd going | Yes — many members, many at once | **data** (`goingPersonaIds`) |
| Listing is on loan | Yes — can be on loan **and** have a queue | **data** (`availabilityState`) |
| Members are queued for a listing | Yes — simultaneous with on-loan | **data** (`queuedPersonaIds`) |
| Ballot is `open` / `closed` | No | **state** |
| A vote has been cast | Yes — many voters | **data** (`ballots`) |
| Proposal is `draft`/`pending`/`approved`/`rejected` | No — mutually exclusive | **state** |

**Failure mode if you get this wrong:** a shipped bug made `queued` a marketplace *state*. Because an
item can be on loan *and* queued simultaneously, `queued` had no coherent transitions — it was declared
with **zero**, and queued listings rendered **no buttons at all**. The validator now catches this
(`stuck_state`), but the correct fix is to model it as data in the first place.

**A second, related failure mode — check this explicitly whenever a doc uses the words "position,"
"queue," "waiting list," or "ranking"/"leaderboard":** if members waiting for something need to see their
**position**, that position is normally a formula (`indexOf(list, $viewer)`, `10-formulas.md`'s canonical
Queue Position pattern) run against a **list on one shared instance** — which only works if the modeling
choice one step earlier put waiting members on a shared list at all, not as their own separate per-member
instances. Found 2026-08-10 (Skill Retrospective): an authoring pass picked a row-per-waiting-member shape
(driven by which archetype looked like the best fit for the *primary* action) without cross-checking that
shape against the doc's *other* stated requirements for the same surface, including "queue position" — by
the time the mismatch was noticed, the structural choice was already locked in, and the requirement got
dropped instead of the shape being reconsidered. **Do this cross-check here, in Step 3, before the
archetype choice locks anything in** — see `20-solved-patterns.md` pattern 2 for the verified-correct
shared-container shape, and reconsider the states-vs-data/archetype decision together if a position-like
requirement doesn't fit the shape you were about to pick.

---

## Step 4 — Write states and transitions

```jsonc
"<workflowType>": {
  "initialState": "<must be a key of states>",
  "states": {
    "<name>": { "label": "<human>", "tone": "positive|negative|warning|info",
                "editableFields": ["<formEntry fields editable in this state>"],
                "isTerminal": false }
  },
  "transitions": [
    { "id": "<unique>", "label": "<button text>", "icon": "<material-icon>",
      "tone": "primary|secondary|destructive",
      "from": ["<state>"], "to": "<state>" | null,
      "guard": { /* who/when */ }, "effects": [ /* what changes */ ] }
  ]
}
```

**Invariants (validator-enforced):**
- Every **non-terminal** state MUST have ≥1 outgoing transition. → else `stuck_state`
- Every state MUST be reachable from `initialState`. → else `unreachable_state`
- `label` MUST be non-empty. → else `missing_label`
- `"to": null` for orthogonal transitions (state unchanged, data changed).

---

## Step 5 — Write `instanceDataSchema`

Every field a workflow uses MUST be declared. Three kinds — pick deliberately:

| Kind | Declare | Written by | Seed in `instanceData`? |
|---|---|---|---|
| Form-entry | `"writableBy": "formEntry"` | User (via `editableFields`) | Yes |
| Effect | `"writableBy": "effect"` | Transition effects | Yes |
| **Computed** | `"formula": "<expr>"` | **Nobody** | **NO — hard error** |

**Rule: if a value can be derived, derive it.** Never store a count, total, ranking, or boolean condition
you could compute.

```jsonc
"goingPersonaIds": { "type": "personaId[]", "writableBy": "effect" },
"goingCount":  { "type": "number", "formula": "size(goingPersonaIds)" },
"isFull":      { "type": "bool",   "formula": "size(goingPersonaIds) >= capacity" }
```

Full type list: [`reference/field-types.md`](../reference/field-types.md).
Full function list: [`reference/formulas.md`](../reference/formulas.md).

---

## Step 6 — Attach guards

For each transition, ask: *who may fire this, and under what conditions?*

| Requirement | Guard kind |
|---|---|
| "only organizers" | `allowedPersonaIds` |
| "only if not already in the list" | `actorInList: { key, present: false }` |
| "only if the item is available" | `instanceDataEquals: { key, value }` |
| "only if there's room" / any computed condition | `formula` |
| "only if they RSVP'd to the linked event" | `relatedListMembership` (cross-instance) |
| "only if they've paid dues" | `requiresWorkflowsComplete` (cross-workflow) |

All guards on a transition are **AND**-ed. Full detail: [`reference/guards.md`](../reference/guards.md).

**Rule:** a guard is enforced by the **engine** — it makes `applyTransition` refuse, not merely hide a
button. Never rely on UI hiding for correctness.

---

## Step 7 — Attach effects

For each transition, ask: *what changes when this fires?*

| Requirement | Effect op |
|---|---|
| Set a value | `set` |
| Add to a list (allowing dupes) | `append` |
| Add to a list (no dupes) | `appendUnique` |
| Remove from a list | `removeValue` |
| Bump a counter | `increment` / `decrement` |
| Do one thing or another, conditionally | `branch` (`if`/`then`/`else`) |
| Spawn a new instance (runoff, notification) | `createInstance` |
| Write a field on **another** instance | `set` + `relatedInstance` |

Interpolation: `$actor` → acting persona id · `$timestamp` → now · `{fieldName}` → that field's value.

Full detail: [`reference/effects.md`](../reference/effects.md).

---

## Step 8 — Attach render bindings

For each type, decide where its instances appear, per state and per role.

```jsonc
"renderBindings": [
  { "states": ["open"], "role": "any", "tabId": "calendar",
    "cardSurfaceFamily": "event-rsvp", "bindingKind": "primary" }
]
```

- `tabId` ∈ `calendar` · `marketplace` · `giving` · `admin` (plus any open-vocabulary custom name). `home`
  and `messages` are reserved, system-provided App Shell tabs — **never** target `tabId: "messages"` in a
  `renderBindings` entry (AP-14); `home` is technically valid but should stay curated, not a dumping
  ground (AP-10).
- `role` ∈ `any` · `actor` · `receiver`
- `bindingKind` ∈ `primary` (full/interactive) · `summary` (compact)
- `cardSurfaceFamily` — **only** values from [`archetypes/README.md`](../archetypes/README.md)

**One type may bind to several tabs.** A proposal binds to `home` (role `actor` — its author tracks it)
*and* `admin` (role `receiver` — the organizer decides it). That is one workflow, two surfaces — not two
workflows.

A state with no binding does not render. This is the correct way to hide drafts.

Full detail: [`reference/render-bindings.md`](../reference/render-bindings.md).

---

## Step 9 — Write `workflowInstances` (seed data)

```jsonc
{ "instanceId": "<unique>", "workflowType": "<a declared type>",
  "currentState": "<a declared state of that type>",
  "createdByPersonaId": "<a declared persona>",
  "instanceData": { /* declared fields only; NO computed fields */ } }
```

**Invariants:**
- `instanceId` unique across the package.
- `workflowType` MUST exist in `workflowDefinitions`.
- `currentState` MUST be a declared state of that type.
- Every `instanceData` key MUST be declared in that type's `instanceDataSchema`.
- Every `required: true` non-computed field MUST be present.
- **NO computed field may appear.**
- Any cross-instance reference field (e.g. `eventId`) MUST name an existing `instanceId`.

---

## Step 9.5 — Build the requirement traceability table (MANDATORY OUTPUT, not just an internal check)

**Why this step exists:** every real defect found in a skill-authored package's independent judge review so
far has been the same shape — a real, explicit product-doc requirement, quietly unimplemented, discovered
only because a *second*, independent pass re-read the doc and checked. One case (Chess Club's
`chess-pairing-queue`) went further: the authoring pass didn't just miss the requirement, it **justified**
dropping it with a claim that a `grep` of the doc's own persona/tab table directly contradicted. Passing the
validator and doing the Step 10 anti-pattern check do not catch this class of error — both check the JSON's
internal consistency, never JSON-against-doc coverage. This step makes that coverage check an explicit,
citable **output artifact** instead of an implicit judgment call, so both you and whoever reviews your
output can mechanically verify nothing was silently dropped.

**Procedure — do this for every workflow, before Step 10:**

1. **Collect every doc row that mentions this workflow.** Search the product doc's §3/§3.1, §5, §6, §7, and
   §9 (B25 Semantic Interaction Models) tables for every row naming this workflow (by its doc-side id or its
   product-surface name).
2. **Split each row into atomic requirements.** A cell like "queue position and assignment result" is
   **two** requirements, not one — split on commas, "and", and slashes. A cell like "browse, list item,
   request loan, join waitlist, claim giveaway, return item" is six. Under-splitting is how a real
   requirement (like "queue position") gets silently absorbed into a broader claim of "yeah I covered
   that row" without ever being checked individually.
3. **For each atomic requirement, find and cite the exact JSON construct that satisfies it** — a field
   name, a transition id, a `renderBinding`, a `visibility`/`readGuard` clause. "Satisfies it" means: point
   at the literal JSON, not a description of intent. If you cannot point at real JSON, it is not satisfied.
4. **If nothing satisfies it, do one of exactly two things — never a third:**
   - **Add the missing construct now**, then cite it (this is the common case — most gaps found this way
     are just an omission, fixable in the same pass).
   - **Mark it `not_implemented`, with `reasoning` that cites a real, checked constraint** — a specific
     validator rule, a specific closed enum (`render-bindings.md`'s `tabId` list, `archetypes.md`'s 9 real
     families), a specific missing `formulas.md` function, or a specific `platform-services.md` ❌
     Not-implemented row. **Reasoning that isn't grounded in one of those citations is not a valid
     `not_implemented` reason — re-read `render-bindings.md` before asserting a persona/tab/grammar
     restriction exists.** This is exactly the check that would have caught Chess Club's false claim:
     "Player has no admin-tab access" is not a real grammar restriction (per-persona tab sets are
     explicitly not in grammar v1, and the workflow's own binding already used `role: "any"` on that tab) —
     a `reasoning` field forced to cite where that constraint supposedly lives would have failed to find a
     citation and forced the real fix instead.
5. **Also check `solved-patterns.md`** (fetch it the same way you fetched this file, if it's part of your
   read set — check `00-INSTRUCTIONS.md`'s current file list) for each requirement — if its shape matches a
   named pattern there, use that pattern's verified-correct shape directly instead of re-deriving one from
   scratch (and instead of reinventing the "looks plausible, is wrong" shape that pattern exists to warn
   against).

**Output format** — emit this as a real JSON artifact in your response (not prose describing that you did
this check), one object per workflow:

```jsonc
{
  "workflow": "chess-pairing-queue",
  "docRows": [
    "§7 Persona And State Matrix: Receiver state column",
    "§9 B25 Semantic Interaction Models: Result and receiver state column"
  ],
  "requirements": [
    {
      "requirement": "waiting players see queue position",
      "docCitation": "§7 Receiver-state column: 'waiting players see queue position and assignment result'",
      "status": "implemented",
      "satisfiedBy": { "field": "waitingPlayerNames",
        "mechanism": "ordered list; each player's list index is their real, visible position" }
    },
    {
      "requirement": "assignment result",
      "docCitation": "§7 Receiver-state column (same cell, second clause)",
      "status": "implemented",
      "satisfiedBy": { "field": "assignments",
        "mechanism": "append-only list of {playerName, opponent, board, assignedAt} set by assign-pairing" }
    },
    {
      "requirement": "real-time push notification to waiting players when a pairing is assigned",
      "docCitation": "§9 B25 (if the doc had required this — illustrative only, this example package does not)",
      "status": "not_implemented",
      "reasoning": "No push-notification platform service exists (platform-services.md: 'Push notifications' — ❌ Not implemented). An in-app notificationInbox row could substitute but was out of this pass's scope; not silently dropped, named here."
    }
  ]
}
```

`status` is one of exactly three values: `"implemented"`, `"not_implemented"` (with required `reasoning`),
or `"partial"` (implemented for some but not all of the requirement's stated cases — also requires
`reasoning` explaining the uncovered part). There is no fourth option and no way to omit a row you found in
Step 1 of this procedure.

**This table is a required part of your final response**, not an internal scratchpad — list every
`not_implemented`/`partial` row again in your Step 12 gap report, cross-referenced by workflow and
requirement so the two don't drift apart.

---

## Step 10 — Self-check against anti-patterns

Load [`guide/04-antipatterns.md`](./04-antipatterns.md) and check the emitted JSON against every
detection rule. Fix before proceeding.

---

## Step 11 — Validate (MANDATORY GATE)

```bash
dart run loom_ux_judges:community_package_validator --package <your-file>.jsonc
```

**A community that does not pass is not a deliverable.** On failure, use the error→fix table in
[`guide/05-validation.md`](./05-validation.md), repair, re-run. Repeat until clean.

**Never** "fix" a failure by weakening the validator or by deleting the requirement. If the grammar
genuinely cannot express the requirement, **stop and report the gap** (see hard rule 8 in the
[README](../README.md)).

---

## Step 12 — Report gaps honestly

If any requirement could not be expressed:

- Mark the location in the JSON with a `// NEEDS IMPLEMENTATION: <what and why>` comment.
- List every such gap in your final response.
- **Do not** substitute a hardcoded value for a computed one, a scripted card for a real interaction, or
  a UI-only check for an engine guard. Those are the exact failures the archetype audit was created to
  eliminate.

---

## Canonical minimal package

Adapt this. It is complete and valid — nothing elided.

```jsonc
{
  "schemaVersion": 1,
  "packageId": "init_hiking_club_1",
  "communityId": "community_hiking_club",
  "communityHandle": "hiking-club",
  "displayName": "Hiking Club",
  "extensionId": "ext_hiking_club",
  "branding": { "accentColor": "#2D6A4F" },
  "seedDataFiles": [],

  "experience": {
    "experienceSchemaVersion": 2,
    "workflowGrammarVersion": 1,

    "displayName": "Hiking Club",
    "tagline": "Weekend trails for the neighbourhood.",
    "accentColor": "#2D6A4F",

    "personas": [
      { "personaId": "hiking-organizer", "label": "Organizer", "roleLabel": "Organizer",
        "description": "Plans hikes." },
      { "personaId": "hiking-member", "label": "Member", "roleLabel": "Member",
        "description": "Joins hikes." }
    ],

    "workflowDefinitions": {
      "hike-rsvp": {
        "initialState": "open",
        "states": {
          "open":      { "label": "Signups open", "tone": "positive",
                         "editableFields": ["title", "eventDate", "capacity"] },
          "cancelled": { "label": "Cancelled", "tone": "negative", "isTerminal": true }
        },
        "transitions": [
          {
            "id": "rsvp-going", "label": "I'm going", "icon": "hiking", "tone": "primary",
            "from": ["open"], "to": null,
            "guard": {
              "allowedPersonaIds": ["hiking-member"],
              "actorInList": { "key": "goingPersonaIds", "present": false },
              "formula": "size(goingPersonaIds) < capacity"
            },
            "effects": [
              { "op": "appendUnique", "key": "goingPersonaIds", "value": "$actor" }
            ]
          },
          {
            "id": "rsvp-withdraw", "label": "Can't make it", "tone": "secondary",
            "from": ["open"], "to": null,
            "guard": {
              "allowedPersonaIds": ["hiking-member"],
              "actorInList": { "key": "goingPersonaIds", "present": true }
            },
            "effects": [
              { "op": "removeValue", "key": "goingPersonaIds", "value": "$actor" }
            ]
          },
          {
            "id": "cancel-hike", "label": "Cancel hike", "tone": "destructive",
            "from": ["open"], "to": "cancelled",
            "guard": { "allowedPersonaIds": ["hiking-organizer"] }
          }
        ],
        "renderBindings": [
          { "states": ["open"], "role": "any", "tabId": "calendar",
            "cardSurfaceFamily": "event-rsvp", "bindingKind": "primary" },
          { "states": ["cancelled"], "role": "any", "tabId": "calendar",
            "cardSurfaceFamily": "event-rsvp", "bindingKind": "summary" }
        ],
        "instanceDataSchema": {
          "title":     { "type": "text", "required": true, "writableBy": "formEntry",
                         "labelTemplate": "{value}", "displayContexts": ["tile", "detail"] },
          "eventDate": { "type": "date", "required": true, "writableBy": "formEntry",
                         "sortable": true, "displayIcon": "calendar_today" },
          "capacity":  { "type": "number", "required": true, "writableBy": "formEntry",
                         "displayIcon": "groups_outlined" },
          "goingPersonaIds": { "type": "personaId[]", "writableBy": "effect" },

          "goingCount":     { "type": "number", "formula": "size(goingPersonaIds)",
                              "labelTemplate": "Going: {value}",
                              "displayContexts": ["tile", "detail"] },
          "spotsRemaining": { "type": "number", "formula": "capacity - size(goingPersonaIds)" },
          "isFull":         { "type": "bool",   "formula": "size(goingPersonaIds) >= capacity" }
        }
      }
    },

    "workflowInstances": [
      {
        "instanceId": "hike-eagle-ridge",
        "workflowType": "hike-rsvp",
        "currentState": "open",
        "createdByPersonaId": "hiking-organizer",
        "instanceData": {
          "title": "Eagle Ridge loop",
          "eventDate": "2026-08-02",
          "capacity": 12,
          "goingPersonaIds": ["hiking-member"]
        }
      }
    ]
  }
}
```
